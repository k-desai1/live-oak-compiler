package assignment2;

public class TeropNode extends ASTNode{
    ASTNode condition;
    ASTNode t;
    ASTNode f;
    int id;

    public TeropNode(){
        nodeType = "Terop";
    }
    
}
